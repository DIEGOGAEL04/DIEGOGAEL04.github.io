/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Base_Datos.Proyecto;
import Base_Datos.formularios.Frm_menu_Principla;
/**
 *
 * @author HP
 */
public class Proyecto_ABC {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Frm_menu_Principla.main(args);
    }
    
}
